
// Please, DO NOT touch these values, unless you know what you're doing, and you're experienced with optifine

//-----Waving Geometry-----//

//#define WAVING_CAMERA
#define WAVING_LEAVES
#define WAVING_VINES
#define WAVING_GRASS
#define WAVING_FLOWERS
#define WAVING_FIRE
#define WAVING_LAVA
#define WAVING_LILYPAD
#define WAVING_NETHER_WART
#define WAVING_SAPLINGS
#define WAVING_CROPS
#define WAVING_MUSHROOM
#define WAVING_METALLIC
#define WAVING_DEADBUSH
#define WAVING_UNDERWATER
#define WorldTimeAnimation
//#define GLOWSTONE
//#define SEA_LANTERN
